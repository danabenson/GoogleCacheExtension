CacheExtension
====================
